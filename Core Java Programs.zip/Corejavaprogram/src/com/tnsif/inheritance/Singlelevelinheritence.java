package com.tnsif.inheritance;

public class Singlelevelinheritence {

	public static void main(String[] args) {
		Student s=new Student("suma","bangalore",8765479l,9845094342l);
		System.out.println(s);
		
		Student s1=new Student(1,"shreys");
		System.out.println(s1);
	}
}
