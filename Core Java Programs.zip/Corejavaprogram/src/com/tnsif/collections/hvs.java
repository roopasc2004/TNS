package com.tnsif.collections;

public class hvs {
public static void main(String[] args) {
	System.out.println("hdghj");
}
}
