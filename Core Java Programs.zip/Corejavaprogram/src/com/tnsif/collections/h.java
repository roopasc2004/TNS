package com.tnsif.collections;

import java.util.Stack;

public class h {
public static void main(String[] args) {
	Stack<Integer> s=new Stack<Integer>();
	s.push(9);
	s.push(2);
	s.push(6);
	s.push(4);
	
	System.out.println(s.search(0));
}
}
