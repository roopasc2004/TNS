package com.tnsif.setdemo;

public class SetDemo {
public static void main(String[] args) {
	SetOperation.operations();
}
}
