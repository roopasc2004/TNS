package com.tnsif.overloading;

public class Testoverloading {
	
public static void main(String[] args) {
	Addition a=new Addition();
	System.out.println(a.add(7, 2));
	System.out.println(a.add(6, 5, 4));
}
}
