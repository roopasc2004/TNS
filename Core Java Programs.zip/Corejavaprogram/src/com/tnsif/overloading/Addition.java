package com.tnsif.overloading;
// to demostarte overloading
public class Addition {
int add(int a,int b) {
	return a+b;
}
int add(int a,int b,int c) {
	return a+b+c;
}
}
