package com.tnsif.superkeyword;
//To demostarte super keyword
public class SuperDemo {
	
 int a=60;   // data member
 
 void drink() {
	 System.out.println("tea");
	 
 }
 
 
 SuperDemo(){  //constructor
	 System.out.println("welcome");
 }
}
