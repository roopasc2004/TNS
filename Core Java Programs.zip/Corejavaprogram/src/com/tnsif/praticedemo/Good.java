package com.tnsif.praticedemo;



public class Good extends Thread{
	
	public void run() {
		System.out.println("exclipse "+Thread.currentThread().getId());
	}
	
}


	


