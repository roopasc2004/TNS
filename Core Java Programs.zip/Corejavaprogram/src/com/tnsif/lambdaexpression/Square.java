package com.tnsif.lambdaexpression;
@FunctionalInterface
public interface Square {
int caluculate(int x);
}
