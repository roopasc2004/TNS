package com.tnsif.lambdaexpression;

// to demostrate lambda expression
@FunctionalInterface
public interface Message {
	
 public String greet();       // abstarct method
 
}
