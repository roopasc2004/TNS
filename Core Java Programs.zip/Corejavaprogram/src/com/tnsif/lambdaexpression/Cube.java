package com.tnsif.lambdaexpression;
@FunctionalInterface

public interface Cube {
	
int calculate(int a);

}
