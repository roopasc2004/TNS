package com.tnsif.finalvariable;

public class Finalvariable {

	final int x=8;   // final variable
	final static int y;
	static void change() {
		
	}
	static {
		y=70;
		
	}
	}
	

