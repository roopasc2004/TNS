package com.tnsif.finalvariable;

//public class FinalmethodDemo extends Finalmethod{

//	@Override
//	final void show() {   // final method
//		System.out.println("welcome");
//	}
//}
