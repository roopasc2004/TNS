package com.tnsif.finalvariable;

public final class Finalmethod {
final int a=9;

final void show() {   // final method
	System.out.println("value of a"+ a);
}
}
