package com.tnsif.override;
// to demostarte override

public class Rbi {
	
public float getRateofInterest() {
	return 7.8f;
}
}
