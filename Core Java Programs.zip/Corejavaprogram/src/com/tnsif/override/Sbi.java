package com.tnsif.override;

public class Sbi extends Rbi {
	
@Override
public float getRateofInterest() {
	return 5.6f;
}
}
