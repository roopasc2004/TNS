package com.tnsif.pratice;

public class Second {
int name=9;
int h=80;
}
