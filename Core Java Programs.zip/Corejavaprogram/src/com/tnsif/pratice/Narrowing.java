package com.tnsif.pratice;

public class Narrowing {

}
