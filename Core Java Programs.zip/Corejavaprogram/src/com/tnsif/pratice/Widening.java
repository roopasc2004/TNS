package com.tnsif.pratice;

public class Widening {
public static void main(String[] args) {

float y=8.5f;
int x=(int)y;
System.out.println("before conversion"+y);
System.out.println("after conversion"+x);
}
}
