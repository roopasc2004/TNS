package com.tnsif.pratice;

public class Firstprogram {
 int name=9;
 int float=8;
}
