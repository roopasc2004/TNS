package com.tnsif.exception;

import java.io.IOException;

// to demostarte throws keyword
public class ThrowsDemo {

	static void display()throws IOException{
	throw new IOException();
}
}