package com.tnsif.exception;

public class NestedDemo {

	public static void main(String[] args) {
		NestedTryblock.check();
	}
}
