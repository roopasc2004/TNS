package com.tnsif.exception;

public class Demo {

	public static void main(String[] args) {
		Division.divide();

	}

}
