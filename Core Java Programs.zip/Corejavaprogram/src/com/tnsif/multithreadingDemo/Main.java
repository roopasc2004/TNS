package com.tnsif.multithreadingDemo;

import com.tnsif.praticedemo.Good;

public class Main {
	public static void main(String[] args) {
		Good e=new Good();
		e.start();
	}

}
