package com.tnsif.program;

import java.util.Scanner;

public class Exce {
public static void main(String[] args) {
	//Encapsulation e=new Encapsulation();
	//e.serialnumber=6;
	//e.name="suma";
	//e.age=23;
	//e.show();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the name");
	String n=sc.nextLine();
	System.out.println(n);
}
}
