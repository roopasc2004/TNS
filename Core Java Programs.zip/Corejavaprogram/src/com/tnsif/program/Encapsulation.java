package com.tnsif.program;
// to demonstrate encapsulation
public class Encapsulation {
int serialnumber;
String name;     //data members
int age;

public void show() {   // member function
	System.out.println("serialnumber  " + serialnumber  +"name " + name+" age "+ age );
}

}

