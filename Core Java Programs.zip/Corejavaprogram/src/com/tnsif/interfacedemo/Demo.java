package com.tnsif.interfacedemo;

public class Demo {
public static void main(String[] args) {
	Nestedinterface n=new Nestedinterface();
	n.print();
	System.out.println(Nestedinterface.id);
}
}
