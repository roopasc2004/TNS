package com.tnsif.interfacedemo;

public class SBI implements Bank {

	@Override
	public float rateofinterest() {
		
		return 9.15f;
	}

}
