package com.tnsif.interfacedemo;

public   class Warrior implements Character{

	@Override
	public void attack() {
		System.out.println("use");
		
	}

}
