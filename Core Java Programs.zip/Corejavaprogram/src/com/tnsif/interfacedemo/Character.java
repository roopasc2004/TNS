package com.tnsif.interfacedemo;
// to demostrate multiple inheritance
public interface Character {

	void attack();
	
}
