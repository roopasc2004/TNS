package com.tnsif.interfacedemo;

public class Demo1 {
public static void main(String[] args) {
	Warrior w=new Warrior();
	w.attack();
	
}
}
