package com.tnsif.interfacedemo;

public interface Childinterface extends ParentInterface {

	void show();
}
