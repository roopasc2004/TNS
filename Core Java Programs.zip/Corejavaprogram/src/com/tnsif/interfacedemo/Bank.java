package com.tnsif.interfacedemo;
// to demostrate interface program
public interface Bank {

	float rateofinterest() ;
		
	
	
}
