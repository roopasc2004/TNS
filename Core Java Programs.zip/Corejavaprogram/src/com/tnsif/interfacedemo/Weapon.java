package com.tnsif.interfacedemo;

public interface Weapon {

	void use();
}
