package com.tnsif.interfacedemo;

public class Excecute {
public static void main(String[] args) {
	Test t =new Test();
	t.show();
	t.print();
}
}
