package com.tnsif.interfacedemo;

public interface ParentInterface {
void print();
}
