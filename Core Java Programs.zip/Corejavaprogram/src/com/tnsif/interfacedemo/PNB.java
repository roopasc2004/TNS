package com.tnsif.interfacedemo;

public class PNB implements Bank{

	@Override
	public float rateofinterest() {
		// TODO Auto-generated method stub
		return 9.2f;
	}

}
