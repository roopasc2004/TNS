package com.tnsif.interfacedemo;

public class Test implements Childinterface {

	@Override
	public void print() {
		System.out.println("print ");
		
	}

	@Override
	public void show() {
		System.out.println("show");
		
	}

}
