 package com.tnsif.staticprogram;

// to demostarte static block

public class Staticblockdemo {
	
	// static block
static {
	System.out.println("welcome");
}
public static void main(String[] args) {
	System.out.println("hello world");
}
}
