package com.tnsif.staticprogram;

public class Demo {
public static void main(String[] args) {
	Employee e1=new Employee(1,"sushma");
	Employee e2=new Employee(2,"kushma");
	Employee e3=new Employee(3,"reshma");
	e1.display();
	e2.display();
	e3.display();
}
}
